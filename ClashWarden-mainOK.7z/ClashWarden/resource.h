﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 ClashWarden.rc 使用
//
#define IDD_CLASHWARDEN_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_Main                 130
#define IDD_DIALOG_Option               132
#define IDD_DIALOG_About                133
#define IDC_TAB1                        1000
#define IDC_BTNStart                    1003
#define IDC_CTun                        1004
#define IDC_BTNStop                     1005
#define IDC_BTNCfg                      1006
#define IDC_BTNIP                       1007
#define IDC_BUTTON7                     1008
#define IDC_BTNConsole                  1008
#define IDC_TSta                        1009
#define IDC_TStatus                     1009
#define IDC_TCfgTime                    1010
#define IDC_TIPTime                     1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
